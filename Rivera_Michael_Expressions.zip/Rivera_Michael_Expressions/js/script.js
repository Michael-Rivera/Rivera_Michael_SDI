/**
 * Created by michaelrivera1 on 5/12/15.
 */
var a = 3;
//a ++;
a--;
console.log (a);